// 1)
var numberOfUsers = 21323;
var result = numberOfusers / 2;
result = Math.floor(result);
console.log(result);

// 2)
console.log(Math.sqrt(144));

// 3)
var postCode = '02-381';
console.log( postCode.indexOf('-') !== -1 );
console.log( postCode.lastIndexOf('-') !== -1 );

